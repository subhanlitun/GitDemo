#!E:\Python\Basics

import ModulesM1

ModulesM1.print_func("test name")
