#Input

k =input("Enter some input value ")
print("entered value is "+k)