def print_func( par ):
   print("Hello : ", par)