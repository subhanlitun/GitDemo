from Phone import *

Pots.Pots()
Isdn.Isdn()
G3.G2()