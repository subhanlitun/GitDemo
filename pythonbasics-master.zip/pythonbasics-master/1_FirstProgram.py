print("Hello Python")

''' Keywords
and	        exec	    not
as	        finally	    or
assert	    for	        pass
break	    from	    print
class	    global	    raise
continue	if	        return
def	        import	    try
del	        in	        while
elif	    is	        with
else	    lambda	    yield
except		
'''
'''Multi line

total = item_one + \
        item_two + \
        item_three

{}[]() - Also works with multi line
'''

#Comments in python

''' Command line execution

$ python -h
usage: python [option] ... [-c cmd | -m mod | file | -] [arg] ...
Options and arguments (and corresponding environment variables):
-c cmd : program passed in as string (terminates option list)
-d     : debug output from parser (also PYTHONDEBUG=x)
-E     : ignore environment variables (such as PYTHONPATH)
-h     : print this help message and exit

'''