def G2():
    print ("I'm G3.G2 Phone")